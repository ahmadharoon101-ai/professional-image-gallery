// ========================================
// PROFESSIONAL IMAGE GALLERY - JAVASCRIPT
// Advanced Features: Upload, Delete, Like, Comments, Search, Favorites, Slideshow, Zoom
// ========================================

// ---------- PHOTO DATA WITH METADATA ----------
let photos = [
  { id: 1,  category: 'nature',   title: 'Ridge Line',      seed: 'nature1',   exif: 'f/8 · 1/250 · ISO 100', isCustom: false },
  { id: 2,  category: 'urban',    title: 'Glass Corridor',  seed: 'urban1',    exif: 'f/4 · 1/500 · ISO 200', isCustom: false },
  { id: 3,  category: 'portrait', title: 'Window Light',    seed: 'portrait1', exif: 'f/1.8 · 1/200 · ISO 400', isCustom: false },
  { id: 4,  category: 'street',   title: 'Crosswalk',       seed: 'street1',   exif: 'f/5.6 · 1/320 · ISO 200', isCustom: false },
  { id: 5,  category: 'nature',   title: 'Low Tide',        seed: 'nature2',   exif: 'f/11 · 1/125 · ISO 100', isCustom: false },
  { id: 6,  category: 'urban',    title: 'Stairwell',       seed: 'urban2',    exif: 'f/5.6 · 1/160 · ISO 320', isCustom: false },
  { id: 7,  category: 'portrait', title: 'Quiet Profile',   seed: 'portrait2', exif: 'f/2 · 1/250 · ISO 200', isCustom: false },
  { id: 8,  category: 'street',   title: 'Newsstand',       seed: 'street2',   exif: 'f/4 · 1/400 · ISO 200', isCustom: false },
  { id: 9,  category: 'nature',   title: 'Canopy',          seed: 'nature3',   exif: 'f/9 · 1/200 · ISO 100', isCustom: false },
  { id: 10, category: 'urban',    title: 'Night Grid',      seed: 'urban3',    exif: 'f/2.8 · 1/30 · ISO 1600', isCustom: false },
  { id: 11, category: 'portrait', title: 'Studio Cut',      seed: 'portrait3', exif: 'f/2.5 · 1/200 · ISO 100', isCustom: false },
  { id: 12, category: 'street',   title: 'Rain, Avenue B',  seed: 'street3',   exif: 'f/2.8 · 1/250 · ISO 400', isCustom: false },
  { id: 13, category: 'nature',   title: 'Switchback',      seed: 'nature4',   exif: 'f/8 · 1/250 · ISO 100', isCustom: false },
  { id: 14, category: 'urban',    title: 'Concrete Span',   seed: 'urban4',    exif: 'f/6.3 · 1/320 · ISO 200', isCustom: false },
  { id: 15, category: 'portrait', title: 'Backlit',         seed: 'portrait4', exif: 'f/1.8 · 1/320 · ISO 100', isCustom: false },
  { id: 16, category: 'street',   title: 'Corner Vendor',   seed: 'street4',   exif: 'f/4 · 1/250 · ISO 200', isCustom: false },
  { id: 17, category: 'nature',   title: 'Frost Line',      seed: 'nature5',   exif: 'f/10 · 1/200 · ISO 100', isCustom: false },
  { id: 18, category: 'urban',    title: 'Loading Dock',    seed: 'urban5',    exif: 'f/5.6 · 1/250 · ISO 200', isCustom: false },
  { id: 19, category: 'portrait', title: 'Last Light',      seed: 'portrait5', exif: 'f/2.2 · 1/160 · ISO 200', isCustom: false },
  { id: 20, category: 'street',   title: 'Bus Stop',        seed: 'street5',   exif: 'f/4 · 1/320 · ISO 200', isCustom: false },
  { id: 21, category: 'nature',   title: 'Reed Bed',        seed: 'nature6',   exif: 'f/8 · 1/200 · ISO 100', isCustom: false },
  { id: 22, category: 'urban',    title: 'Mezzanine',       seed: 'urban6',    exif: 'f/4 · 1/200 · ISO 400', isCustom: false },
  { id: 23, category: 'portrait', title: 'Half Turn',       seed: 'portrait6', exif: 'f/2 · 1/250 · ISO 100', isCustom: false },
  { id: 24, category: 'street',   title: 'Market Day',      seed: 'street6',   exif: 'f/5.6 · 1/250 · ISO 200', isCustom: false },
];

const imgUrl = (seed, w, h) => `https://picsum.photos/seed/${seed}/${w}/${h}`;

// ---------- STATE MANAGEMENT ----------
const galleryState = {
  viewMode: 'grid',
  isSlideshow: false,
  slideshowInterval: null,
  favorites: new Set(JSON.parse(localStorage.getItem('galleryFavorites') || '[]')),
  likes: new Set(JSON.parse(localStorage.getItem('galleryLikes') || '[]')),
  comments: JSON.parse(localStorage.getItem('galleryComments') || '{}'),
  currentFilter: 'all',
  searchQuery: '',
  zoomLevel: 100,
  nextId: 25,
};

function saveState() {
  localStorage.setItem('galleryFavorites', JSON.stringify(Array.from(galleryState.favorites)));
  localStorage.setItem('galleryLikes', JSON.stringify(Array.from(galleryState.likes)));
  localStorage.setItem('galleryComments', JSON.stringify(galleryState.comments));
}

// ---------- UPLOAD IMAGE FUNCTIONALITY ----------
document.getElementById('imageUpload').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    const newPhoto = {
      id: galleryState.nextId++,
      category: 'nature',
      title: file.name.replace(/\.[^/.]+$/, ''),
      seed: '',
      exif: new Date().toLocaleDateString(),
      isCustom: true,
      data: event.target.result,
    };
    
    photos.unshift(newPhoto);
    renderGalleryGrid();
    filterAndRenderGallery();
    
    e.target.value = '';
    alert(`✅ Image "${newPhoto.title}" uploaded successfully!`);
  };
  reader.readAsDataURL(file);
});

// ---------- CUSTOM CURSOR ----------
const cursorIndicator = document.getElementById('cursorIndicator');
document.addEventListener('mousemove', (e) => {
  if (!cursorIndicator) return;
  cursorIndicator.style.left = (e.clientX - 15) + 'px';
  cursorIndicator.style.top = (e.clientY - 15) + 'px';
});

// ---------- GALLERY GRID RENDERING ----------
function renderGalleryGrid() {
  const grid = document.getElementById('galleryGrid');
  grid.innerHTML = '';
  
  photos.forEach(photo => {
    const frame = document.createElement('figure');
    frame.className = 'frame';
    if (galleryState.favorites.has(photo.id)) {
      frame.classList.add('favorite');
    }
    frame.dataset.category = photo.category;
    frame.dataset.id = photo.id;
    frame.dataset.title = photo.title.toLowerCase();
    frame.tabIndex = 0;
    
    const imgSrc = photo.isCustom ? photo.data : imgUrl(photo.seed, 500, 625);
    
    frame.innerHTML = `
      <span class="frame-number">${String(photo.id).padStart(2, '0')}</span>
      <img src="${imgSrc}" alt="${photo.title}" loading="lazy" decoding="async">
      <figcaption class="frame-caption">
        <p class="title">${photo.title}</p>
        <p class="exif">${photo.exif}</p>
      </figcaption>
    `;
    
    frame.addEventListener('click', () => openLightbox(photo.id));
    frame.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openLightbox(photo.id);
      }
    });
    
    grid.appendChild(frame);
  });
  
  document.getElementById('totalFrames').textContent = photos.length;
}

renderGalleryGrid();

// ---------- SEARCH FUNCTIONALITY ----------
document.getElementById('searchInput').addEventListener('input', (e) => {
  galleryState.searchQuery = e.target.value.toLowerCase();
  filterAndRenderGallery();
});

// ---------- FILTERING ----------
function initializeFilters() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  
  filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      filterBtns.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      galleryState.currentFilter = btn.dataset.filter;
      filterAndRenderGallery();
    });
  });
}

function filterAndRenderGallery() {
  const filterInfo = document.getElementById('filterInfo');
  let visibleCount = 0;
  
  document.querySelectorAll('.frame').forEach((frame) => {
    const categoryMatch = galleryState.currentFilter === 'all' || frame.dataset.category === galleryState.currentFilter;
    const titleMatch = frame.dataset.title.includes(galleryState.searchQuery);
    const isMatch = categoryMatch && titleMatch;
    
    frame.classList.toggle('hide', !isMatch);
    if (isMatch) visibleCount++;
  });
  
  filterInfo.textContent = `Showing ${visibleCount} image${visibleCount !== 1 ? 's' : ''}`;
}

initializeFilters();

// ---------- VIEW MODE TOGGLE ----------
function initializeViewMode() {
  const gridViewBtn = document.getElementById('gridViewBtn');
  const listViewBtn = document.getElementById('listViewBtn');
  const gallery = document.getElementById('galleryGrid');
  
  gridViewBtn.addEventListener('click', () => {
    galleryState.viewMode = 'grid';
    gallery.classList.remove('list-view');
    gridViewBtn.classList.add('active');
    listViewBtn.classList.remove('active');
  });
  
  listViewBtn.addEventListener('click', () => {
    galleryState.viewMode = 'list';
    gallery.classList.add('list-view');
    listViewBtn.classList.add('active');
    gridViewBtn.classList.remove('active');
  });
}

initializeViewMode();

// ---------- FAVORITES ----------
function initializeFavorites() {
  const favoritesBtn = document.getElementById('favoritesBtn');
  let showingFavoritesOnly = false;
  
  favoritesBtn.addEventListener('click', () => {
    showingFavoritesOnly = !showingFavoritesOnly;
    favoritesBtn.classList.toggle('active');
    
    document.querySelectorAll('.frame').forEach((frame) => {
      const isFavorite = galleryState.favorites.has(Number(frame.dataset.id));
      frame.classList.toggle('hide', showingFavoritesOnly && !isFavorite);
    });
    
    const visibleCount = document.querySelectorAll('.frame:not(.hide)').length;
    const filterInfo = document.getElementById('filterInfo');
    filterInfo.textContent = showingFavoritesOnly 
      ? `${visibleCount} favorite${visibleCount !== 1 ? 's' : ''}`
      : `Showing ${visibleCount} image${visibleCount !== 1 ? 's' : ''}`;
  });
}

initializeFavorites();

// ---------- SLIDESHOW ----------
function initializeSlideshow() {
  const slideshowBtn = document.getElementById('slideshowBtn');
  
  slideshowBtn.addEventListener('click', () => {
    galleryState.isSlideshow = !galleryState.isSlideshow;
    
    if (galleryState.isSlideshow) {
      slideshowBtn.classList.add('active');
      slideshowBtn.textContent = '⏸ Stop';
      
      galleryState.slideshowInterval = setInterval(() => {
        lightboxGallery.navigate(1);
      }, 3000);
    } else {
      slideshowBtn.classList.remove('active');
      slideshowBtn.textContent = '▶ Slideshow';
      clearInterval(galleryState.slideshowInterval);
    }
  });
}

initializeSlideshow();

// ---------- LIGHTBOX FUNCTIONALITY ----------
class LightboxGallery {
  constructor() {
    this.lightbox = document.getElementById('lightbox');
    this.lbImage = document.getElementById('lbImage');
    this.lbTitle = document.getElementById('lbTitle');
    this.lbMeta = document.getElementById('lbMeta');
    this.lbClose = document.getElementById('lbClose');
    this.lbPrev = document.getElementById('lbPrev');
    this.lbNext = document.getElementById('lbNext');
    this.lbBackdrop = document.getElementById('lbBackdrop');
    this.imageCounter = document.getElementById('imageCounter');
    this.lightboxIndicators = document.getElementById('lightboxIndicators');
    this.zoomLevel = document.getElementById('zoomLevel');
    this.commentsList = document.getElementById('commentsList');
    this.commentInput = document.getElementById('commentInput');
    this.addCommentBtn = document.getElementById('addCommentBtn');
    this.commentCount = document.getElementById('commentCount');
    this.likeBtn = document.getElementById('lbLike');
    this.likeCount = document.getElementById('likeCount');
    
    this.currentId = null;
    this.visibleIds = [];
    this.isLoading = false;
    
    this.attachEventListeners();
  }
  
  attachEventListeners() {
    this.lbClose.addEventListener('click', () => this.close());
    this.lbBackdrop.addEventListener('click', () => this.close());
    this.lbPrev.addEventListener('click', () => this.navigate(-1));
    this.lbNext.addEventListener('click', () => this.navigate(1));
    
    document.getElementById('lbZoomIn').addEventListener('click', () => this.zoom(1.2));
    document.getElementById('lbZoomOut').addEventListener('click', () => this.zoom(0.8));
    document.getElementById('lbDownload').addEventListener('click', () => this.downloadImage());
    document.getElementById('lbFavorite').addEventListener('click', () => this.toggleFavorite());
    document.getElementById('lbDelete').addEventListener('click', () => this.deleteImage());
    this.likeBtn.addEventListener('click', () => this.toggleLike());
    
    this.addCommentBtn.addEventListener('click', () => this.addComment());
    this.commentInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.addComment();
      }
    });
    
    document.getElementById('toggleComments').addEventListener('click', () => {
      this.commentsList.classList.toggle('hidden');
    });
    
    document.addEventListener('keydown', (e) => {
      if (!this.lightbox.classList.contains('open')) return;
      
      switch (e.key) {
        case 'Escape': this.close(); break;
        case 'ArrowLeft': e.preventDefault(); this.navigate(-1); break;
        case 'ArrowRight': e.preventDefault(); this.navigate(1); break;
        case '+': case '=': e.preventDefault(); this.zoom(1.2); break;
        case '-': e.preventDefault(); this.zoom(0.8); break;
        case '0': e.preventDefault(); this.resetZoom(); break;
      }
    });
  }
  
  getVisibleIds() {
    return Array.from(document.querySelectorAll('.frame:not(.hide)'))
      .map((frame) => Number(frame.dataset.id));
  }
  
  open(photoId) {
    this.currentId = photoId;
    this.visibleIds = this.getVisibleIds();
    this.resetZoom();
    this.render();
    this.lightbox.classList.add('open');
    this.lightbox.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    this.lbClose.focus();
  }
  
  close() {
    if (galleryState.isSlideshow) {
      galleryState.isSlideshow = false;
      document.getElementById('slideshowBtn').classList.remove('active');
      document.getElementById('slideshowBtn').textContent = '▶ Slideshow';
      clearInterval(galleryState.slideshowInterval);
    }
    
    this.lightbox.classList.remove('open');
    this.lightbox.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    this.resetZoom();
  }
  
  navigate(direction) {
    if (this.isLoading) return;
    
    const currentIndex = this.visibleIds.indexOf(this.currentId);
    const newIndex = (currentIndex + direction + this.visibleIds.length) % this.visibleIds.length;
    this.currentId = this.visibleIds[newIndex];
    this.resetZoom();
    this.render();
  }
  
  zoom(factor) {
    galleryState.zoomLevel = Math.max(100, Math.min(300, galleryState.zoomLevel * factor));
    this.lbImage.style.transform = `scale(${galleryState.zoomLevel / 100})`;
    this.zoomLevel.textContent = `${Math.round(galleryState.zoomLevel)}%`;
  }
  
  resetZoom() {
    galleryState.zoomLevel = 100;
    this.lbImage.style.transform = 'scale(1)';
    this.zoomLevel.textContent = '100%';
  }
  
  render() {
    const photo = photos.find((p) => p.id === this.currentId);
    const currentIndex = this.visibleIds.indexOf(this.currentId);
    
    this.lbTitle.textContent = photo.title;
    this.lbMeta.textContent = photo.exif;
    this.imageCounter.textContent = `${currentIndex + 1} / ${this.visibleIds.length}`;
    
    this.isLoading = true;
    this.lbImage.style.opacity = '0';
    
    const img = new Image();
    img.onload = () => {
      this.lbImage.src = img.src;
      this.lbImage.style.opacity = '1';
      this.isLoading = false;
    };
    img.src = photo.isCustom ? photo.data : imgUrl(photo.seed, 1200, 1000);
    
    this.lbPrev.disabled = this.visibleIds.length <= 1;
    this.lbNext.disabled = this.visibleIds.length <= 1;
    
    const favoriteBtn = document.getElementById('lbFavorite');
    if (galleryState.favorites.has(this.currentId)) {
      favoriteBtn.classList.add('favorited');
    } else {
      favoriteBtn.classList.remove('favorited');
    }
    
    if (galleryState.likes.has(this.currentId)) {
      this.likeBtn.classList.add('liked');
    } else {
      this.likeBtn.classList.remove('liked');
    }
    this.likeCount.textContent = photos.find(p => p.id === this.currentId)?.likeCount || 0;
    
    this.renderComments();
    this.updateIndicators(currentIndex);
  }
  
  renderComments() {
    this.commentsList.innerHTML = '';
    const photoComments = galleryState.comments[this.currentId] || [];
    
    if (photoComments.length === 0) {
      this.commentsList.innerHTML = '<div class="no-comments">No comments yet. Be the first to comment!</div>';
      this.commentCount.textContent = '0';
      return;
    }
    
    photoComments.forEach((comment, index) => {
      const commentEl = document.createElement('div');
      commentEl.className = 'comment';
      commentEl.innerHTML = `
        <div class="comment-author">${comment.author}</div>
        <div class="comment-text">${comment.text}</div>
        <div class="comment-time">${new Date(comment.time).toLocaleString()}</div>
        <button class="comment-delete" onclick="lightboxGallery.deleteComment(${index})">Delete</button>
      `;
      this.commentsList.appendChild(commentEl);
    });
    
    this.commentCount.textContent = photoComments.length;
  }
  
  addComment() {
    const text = this.commentInput.value.trim();
    if (!text) return;
    
    if (!galleryState.comments[this.currentId]) {
      galleryState.comments[this.currentId] = [];
    }
    
    galleryState.comments[this.currentId].push({
      author: 'You',
      text: text,
      time: new Date().toISOString(),
    });
    
    saveState();
    this.commentInput.value = '';
    this.renderComments();
  }
  
  deleteComment(index) {
    if (!galleryState.comments[this.currentId]) return;
    galleryState.comments[this.currentId].splice(index, 1);
    saveState();
    this.renderComments();
  }
  
  toggleLike() {
    if (galleryState.likes.has(this.currentId)) {
      galleryState.likes.delete(this.currentId);
    } else {
      galleryState.likes.add(this.currentId);
    }
    saveState();
    
    const photo = photos.find(p => p.id === this.currentId);
    photo.likeCount = (photo.likeCount || 0) + (galleryState.likes.has(this.currentId) ? 1 : -1);
    
    this.likeBtn.classList.toggle('liked');
    this.likeCount.textContent = photo.likeCount;
  }
  
  toggleFavorite() {
    if (galleryState.favorites.has(this.currentId)) {
      galleryState.favorites.delete(this.currentId);
    } else {
      galleryState.favorites.add(this.currentId);
    }
    saveState();
    
    const frame = document.querySelector(`[data-id="${this.currentId}"]`);
    frame.classList.toggle('favorite');
    
    const favoriteBtn = document.getElementById('lbFavorite');
    favoriteBtn.classList.toggle('favorited');
  }
  
  deleteImage() {
    if (confirm(`Are you sure you want to delete "${photos.find(p => p.id === this.currentId).title}"?`)) {
      photos = photos.filter(p => p.id !== this.currentId);
      this.close();
      renderGalleryGrid();
      filterAndRenderGallery();
      alert('✅ Image deleted successfully!');
    }
  }
  
  downloadImage() {
    const photo = photos.find((p) => p.id === this.currentId);
    const link = document.createElement('a');
    link.href = photo.isCustom ? photo.data : imgUrl(photo.seed, 1200, 1000);
    link.download = `${photo.title.replace(/\s+/g, '-')}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  
  updateIndicators(currentIndex) {
    this.lightboxIndicators.innerHTML = '';
    
    this.visibleIds.forEach((_, index) => {
      const indicator = document.createElement('div');
      indicator.className = 'indicator';
      if (index === currentIndex) indicator.classList.add('active');
      indicator.addEventListener('click', () => {
        this.currentId = this.visibleIds[index];
        this.resetZoom();
        this.render();
      });
      this.lightboxIndicators.appendChild(indicator);
    });
  }
}

const lightboxGallery = new LightboxGallery();

function openLightbox(photoId) {
  lightboxGallery.open(photoId);
}
